package com.nhnacademy.certificateissuance.controller;

public interface ControllerBase {
}
