package com.nhnacademy.certificateissuance.repository;

public interface RepositoryBase {
}
