package com.nhnacademy.certificateissuance.domain;

import lombok.Data;

@Data
public class FamilyRelationshipDto {
    private int familySerialNumber;
    private String relationShip;
}
