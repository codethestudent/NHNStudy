package com.nhnacademy.certificateissuance;

public interface Base {
}
